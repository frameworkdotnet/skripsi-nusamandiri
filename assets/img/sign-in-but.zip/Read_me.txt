
This resource has been created by Neil Judges for SerifTuts.com




TERMS OF USE:




All resources made available on Serif Tuts, including but not limited to, icons, images, brushes, shapes, layer styles, patterns, textures, DrawPlus files, WebPlus files, PhotoPlus files, PagePlus files, web elements and templates are free for use in both personal and commercial projects.



You may freely use our resources, without restriction, in software programs, templates and other materials intended for sale or distribution. No attribution or backlinks are required, but any form of spreading the word is always appreciated!



You are not permitted to make the resources found on Serif Tuts available for distribution elsewhere as is without prior consent.




Neil Judges for Serif Tuts


www.Seriftuts.com - www.seriftemplates.com - 
www.flyingcowlabs.com

